#include "Background.h"

void Background::setParams(sf::Vector2f pos_, sf::Vector2f size_, Cfg::Textures texID_, int layer_)
{

	if (layer_ < (int)texID.size() - 1)
	{
		positions[layer_] = pos_;
		sizes[layer_] = size_;
		texID[layer_] = texID_;
	}
	else {

		texID.push_back(texID_);
		positions.push_back(pos_);
		sizes.push_back(size_);
	}
	setLevel(1);
}

void Background::setLevel(int lvlNum)
{
	//back layer
	if (positions.size() > 0)
	{
		positions[0] = { 0.f, -2100.f };
	}

	// mid layer
	if (positions.size() > 1)
	{
		positions[1] = { 0.f, 0.f };
	}

	// layer on bg closest to the back side of player
	if (positions.size() > 2)
	{
		positions[2] = { 0.f,0.f };
	}
}

void Background::update(float dt_)
{
	positions[0] = {positions[0].x - 5.f * dt_, positions[0].y};

}

void Background::render(sf::RenderWindow& wnd_)
{
	if (texID.size() == 0) { return; }
	sf::Sprite spr = {};
	spr.setTexture(Cfg::textures.get((int)Cfg::Textures::BGSTART_BIG));
	spr.setPosition(positions[0]);

	wnd_.draw(spr);
}
