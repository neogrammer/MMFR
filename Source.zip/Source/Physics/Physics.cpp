#include "Physics.h"

const float Physics::Gravity = 1600.f;