#include <GameObjects/TriggerObject.h>

TriggerObject::TriggerObject(std::string filename_, float x_, float y_)
	: GameObject(filename_, x_, y_)
{
}

TriggerObject::~TriggerObject()
{
}
