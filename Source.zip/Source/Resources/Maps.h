#pragma once
#include <Physics/BBox.h>
#include <unordered_map>
#include <vector>
#include <string>
#include <memory>
#include <Animation/Animation.h>

typedef std::unordered_map<std::string, std::unordered_map<std::string, std::vector<BBox>>> BBMap;
typedef std::unordered_map<std::string, std::unordered_map<std::string, std::unique_ptr<Animation>>> AnimMap;